{const a={d:document}
a.s=a.d.createElement('script')
a.s.src='https://cdn.appconsent.io/tcf2/28.10.4/core.bundle.js'
a.d.head.appendChild(a.s)}
